import React from 'react'
import ChildComponent from './ChildComponent'

export default function App() {
 const Users = [
    {
      Name : "Manoj Kumar. M",
      City : "Khammam",
      Age : 29,
      Email : "manoj99@gmail.com",
      PhoneNumber : 7890123456
    },
    {
      Name : "vemkatesh",
      City : "Hyderabad",
      Age : 30,
      Email : "venky12@gmail.com",
      PhoneNumber : 8901234567
    },
    {
      Name : "Kishore",
      City : "Nellore",
      Age : 27,
      Email : "kishore34@gmail.com",
      PhoneNumber : 9012345678
    },
    {Name : "Mahesh",
      City : "Surypet",
      Age : 28,
      Email : "mahesh12@gmail.com",
      PhoneNumber : 7765432189

    },
    {
      Name : "Sagar",
      City : "Khammam",
      Age : 27,
      Email : "sagar34@gmail.com",
      PhoneNumber : 9988123456
    }
  ]
  return (
    <div>
      {Users.map((user)=>(
        <ChildComponent
        Name = {user.Name}
        City = {user.City}
        Age = {user.Age}
        Email = {user.Email}
        PhoneNumber = {user.PhoneNumber}
        />
))}
    </div>
  );
}

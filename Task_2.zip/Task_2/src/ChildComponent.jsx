import React from 'react'

export default function ChildComponent(props) {
  return (
    <div className="user">
        <h1>User Details</h1>

        <p><strong>Name :</strong> {props.Name}</p>
        <p><strong>City :</strong> {props.City}</p>
        <p><strong>Age :</strong> {props.Age}</p>
        <p><strong>Email :</strong> {props.Email}</p>
        <p><strong>Phone Number :</strong> {props.PhoneNumber}</p>
    </div>
  )
}
